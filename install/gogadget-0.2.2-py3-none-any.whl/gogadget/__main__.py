from .config import APP_NAME
from .main import app

app(prog_name=APP_NAME)
