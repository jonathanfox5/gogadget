from whisperx_numpy2_compatibility.transcribe import cli

if __name__ == "__main__":
    cli()
